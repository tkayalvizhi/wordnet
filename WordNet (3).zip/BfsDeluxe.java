/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.Queue;

public class BfsDeluxe {
    private int minDist;
    private int shortest_common_ancestor;
    private int V;
    private Digraph digraph;
    private Queue<Integer> q= new Queue<>();
    private boolean[] markedFromW;
    private boolean[] markedFromV;
    private int[] distTo;


    public BfsDeluxe (Digraph g, int v, int w) {
        V = g.V();
        minDist = V;
        digraph = g;

        markedFromW = new boolean[V];
        markedFromV = new boolean[V];
        distTo = new int[V];


        markedFromV[v] = true;
        markedFromW[w] = true;

        q = new Queue<>();
        q.enqueue(v);
        q.enqueue(w);

        bfs();
    }

    public BfsDeluxe(Digraph g, Iterable<Integer> v, Iterable<Integer> w) {
        V = g.V();
        minDist = V;
        digraph = g;

        markedFromW = new boolean[V];
        markedFromV = new boolean[V];
        distTo = new int[V];

        for (int v1 : v) {
            markedFromV[v1] = true;
            q.enqueue(v1);
        }

        for (int w1 : w) {
            if (markedFromV[w1]) {
                shortest_common_ancestor = w1;
                minDist = 0;
                break;
            }
            markedFromW[w1] = true;
            q.enqueue(w1);
        }

        bfs();

    }

    private void bfs() {
        int dist;
        int vertex;
        while (!q.isEmpty()) {

            // deque an int from queue -  child
            vertex = q.dequeue();
            for (int adj : digraph.adj(vertex)) {
                // if unmarked, mark child
                if (!markedFromW[adj] && !markedFromV[adj]) {
                    markedFromW[adj] = markedFromW[vertex];
                    //pass markedByV from child to ancestor
                    markedFromV[adj] = markedFromV[vertex];
                    distTo[adj] = distTo[vertex] + 1;
                    q.enqueue(adj);
                }
                else if (markedFromV[adj] && markedFromW[adj]) {
                    dist = distTo[adj] + distTo[vertex] + 1;
                    if (dist < minDist) {
                        minDist = dist;
                        shortest_common_ancestor = adj;
                    }
                }
                // if marked, check if marked by v of child and ancestor are same. if different then we have found the common ancestor.
                else if (markedFromV[vertex] != markedFromV[adj]) {
                    markedFromV[adj] = true;
                    markedFromW[adj] = true;
                    dist = distTo[adj] + distTo[vertex] + 1;
                    if (dist < minDist) {
                        minDist = dist;
                        shortest_common_ancestor = adj;
                    }
                }

            }
        }
    }

    public int getMinDist() {
        if (minDist == V) return -1;
        else return minDist;
    }

    public int getShortest_common_ancestor() {
        if (minDist == V) return -1;
        else return shortest_common_ancestor;
    }


    public static void main(String[] args) {

    }
}
