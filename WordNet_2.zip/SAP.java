import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.algs4.StdOut;

public class SAP {
    private static final boolean MARKED_FROM_V = true;

    private final Digraph digraph;
    private boolean[][] marked;
    private final int V;


    // constructor takes a digraph (not necessarily a DAG)
    public SAP(Digraph G) {
        if (G == null) throw new IllegalArgumentException("Digraph argument to SAP is null");
        digraph = G;
        this.V = G.V();

    }

    private void validate(int v) {
        if (v < 0 || v >= V) throw new IllegalArgumentException("vertex index: " + v + " is not valid");
    }

    // length of shortest ancestral path between v and w; -1 if no such path
    public int length(int v, int w) {
        validate(v);
        validate(w);

        if (v == w) return 0;
        marked = new boolean[V][2];
        int[] distTo = new int[V];

        marked[v][0] = true;
        marked[v][1] = MARKED_FROM_V;
        marked[w][0] = true;


        Queue<Integer> q = new Queue<>();
        q.enqueue(v);
        q.enqueue(w);

        int vertex;
        while (!q.isEmpty()) {

            // deque an int from queue -  child
            vertex = q.dequeue();
            for (int adj : digraph.adj(vertex)) {
                // if unmarked, mark child
                if (!marked[adj][0]) {
                    marked[adj][0] = true;
                    //pass markedByV from child to ancestor
                    marked[adj][1] = marked[vertex][1];
                    distTo[adj] = distTo[vertex] + 1;
                    q.enqueue(adj);
                }
                // if marked, check if marked by v of child and ancestor are same. if different then we have found the common ancestor.
                else if (marked[vertex][1] != marked[adj][1]) {
                    return distTo[adj] + distTo[vertex] + 1;
                }
            }
        }

        return -1;
    }

    // a common ancestor of v and w that participates in a shortest ancestral path; -1 if no such path
    public int ancestor(int v, int w) {
        validate(v);
        validate(w);
        if (v == w) return v;
        marked = new boolean[V][2];


        marked[v][0] = true;
        marked[v][1] = MARKED_FROM_V;
        marked[w][0] = true;

        Queue<Integer> q = new Queue<>();
        q.enqueue(v);
        q.enqueue(w);

        int vertex;
        while (!q.isEmpty()) {

            // deque an int from queue -  child
            vertex = q.dequeue();
            for (int adj : digraph.adj(vertex)) {
                // if unmarked, mark child
                if (!marked[adj][0]) {
                    marked[adj][0] = true;
                    //pass markedByV from child to ancestor
                    marked[adj][1] = marked[vertex][1];
                    q.enqueue(adj);
                }
                // if marked, check if marked by v of child and ancestor are same. if different then we have found the common ancestor.
                else if (marked[vertex][1] != marked[adj][1]) {
                    return adj;
                }
            }
        }
        return -1;
    }

    // length of shortest ancestral path between any vertex in v and any vertex in w; -1 if no such path
    public int length(Iterable<Integer> v, Iterable<Integer> w) {
        if (v == null || w == null) throw new IllegalArgumentException("Null arguments passed to length() in SAP");

        for (int i : v) validate(i);
        for (int j : w) validate(j);


        marked = new boolean[V][2];
        Queue<Integer> q = new Queue<>();
        int[] distTo = new int[V];

        for (int v1 : v) {
            marked[v1][0] = true;
            marked[v1][1] = MARKED_FROM_V;
            q.enqueue(v1);
        }

        for (int w1 : w) {
            if (marked[w1][1] == MARKED_FROM_V) {
                return w1;
            }
            marked[w1][0] = true;
            q.enqueue(w1);
        }

        int vertex;
        while (!q.isEmpty()) {
            vertex = q.dequeue();
            for (int adj : digraph.adj(vertex)) {
                // if unmarked, mark child
                if (!marked[adj][0]) {
                    marked[adj][0] = true;
                    //pass markedByV from child to ancestor
                    marked[adj][1] = marked[vertex][1];
                    distTo[adj] = distTo[vertex] + 1;
                    q.enqueue(adj);
                }
                // if marked, check if marked by v of child and ancestor are same. if different then we have found the common ancestor.
                else if (marked[vertex][1] != marked[adj][1]) {
                    return distTo[vertex] + distTo[adj] + 1;
                }
            }
        }

        return -1;
    }

    // a common ancestor that participates in shortest ancestral path; -1 if no such path
    public int ancestor(Iterable<Integer> v, Iterable<Integer> w) {
        if (v == null || w == null) throw new IllegalArgumentException("Null arguments passed to ancestor() in SAP");
        for (int i : v) validate(i);
        for (int j : w) validate(j);

        marked = new boolean[V][2];
        Queue<Integer> q = new Queue<>();

        for (int v1 : v) {
            marked[v1][0] = true;
            marked[v1][1] = MARKED_FROM_V;
            q.enqueue(v1);
        }

        for (int w1 : w) {
            if (marked[w1][1] == MARKED_FROM_V) {
                return w1;
            }
            marked[w1][0] = true;
            q.enqueue(w1);
        }

        int vertex;
        while (!q.isEmpty()) {
            vertex = q.dequeue();
            for (int adj : digraph.adj(vertex)) {
                // if unmarked, mark child
                if (!marked[adj][0]) {
                    marked[adj][0] = true;
                    //pass markedByV from child to ancestor
                    marked[adj][1] = marked[vertex][1];

                    q.enqueue(adj);
                }
                // if marked, check if marked by v of child and ancestor are same. if different then we have found the common ancestor.
                else if (marked[vertex][1] != marked[adj][1]) {
                    return adj;
                }
            }
        }

        return -1;
    }


    // do unit testing of this class
    public static void main(String[] args) {
        In in = new In(args[0]);
        Digraph G = new Digraph(in);
        SAP sap = new SAP(G);

        int v = 10;
        int w = 7;
        int length = sap.length(v, w);
        int ancestor = sap.ancestor(v, w);
        StdOut.printf("length = %d, ancestor = %d\n", length, ancestor);

    }

}
